QuickTiny standalone tools / Outils autonomes QuickTiny

Open index.html to browse all 58 tools, or open any tool HTML directly. Each file contains its CSS and JavaScript. No server or internet connection required. Hardware access and media codecs depend on your browser. OCR and speech recognition engines/models are included in their HTML files; those files are larger. Keep the files together for navigation.

Use the English and Français buttons with the flags to switch languages. The preference follows navigation and is saved locally when the browser permits it. Your files and inputs are never uploaded.

PDF to JPG: choose your scanned PDF, specify a maximum size per JPG, then extract the embedded images. Original JPG bytes are preserved if they fit; larger images are recompressed. If the PDF contains no JPG images, choose whole-page conversion. Small limits can reduce dimensions and text detail. Each JPG respects the requested limit; the ZIP itself can be larger.

Ouvrez index.html pour parcourir les 58 outils, ou ouvrez directement la page HTML de votre choix. Chaque fichier contient son CSS et son JavaScript. Aucun serveur ni accès internet nécessaire. Gardez les fichiers ensemble pour utiliser la navigation.

Utilisez les boutons English et Français avec les drapeaux pour changer de langue. Vos fichiers et vos saisies restent sur votre appareil.

PDF vers JPG : choisissez votre PDF numérisé, indiquez une taille maximale par JPG puis extrayez les images intégrées. Le JPG original est conservé si sa taille convient ; les images plus grandes sont recompressées. Si le PDF ne contient aucun JPG, choisissez la conversion des pages entières. La limite s’applique à chaque JPG, pas au ZIP.
